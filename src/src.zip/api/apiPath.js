
export const BASE_URL = 'http://localhost:8081';

// 'http://43.202.221.91:8081';